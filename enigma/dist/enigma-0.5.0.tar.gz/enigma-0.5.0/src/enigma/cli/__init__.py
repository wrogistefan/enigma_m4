"""
Command-line interface for the Enigma simulator.
"""
